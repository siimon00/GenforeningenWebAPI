(function () {
    'use strict';

    module.exports = {
        MongoDBUtil: require('./mongodb.util')
    };

})();
